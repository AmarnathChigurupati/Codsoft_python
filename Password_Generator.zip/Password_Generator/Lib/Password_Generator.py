#importing necessary packages
import string
import random

#defining a function
def Password_generator(pass_length):
    password=""
    #giving combinations
    characters=string.ascii_letters+string.digits+string.punctuation
    for _ in range(pass_length) :
        password +=random.choice(characters)
    print("Generated Password is: ",password)
#user case
a=int(input("Enter the length of password that has to be generated: "))
Password_generator(a)
